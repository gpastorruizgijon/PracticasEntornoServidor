<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('recycling_plants', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    $table->string('address');
    $table->string('city');
    $table->float('max_capacity_kg'); // Capacidad máxima
    $table->softDeletes();
    $table->timestamps();
});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('recycling_plants');
    }
};
